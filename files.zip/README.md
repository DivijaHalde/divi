# Faculty Ranking & Evaluation System (A. P. Shah Institute of Technology)

Files: index.html, style.css, script.js, logo.png. No build step and no dependencies.

Run: open index.html in a browser (or use Live Server in your editor).

Demo logins: Admin hod/hod123 or cohod/cohod123 | Faculty: pick name, password faculty123 | Student: 123456/123456

Data is stored in the browser (localStorage, key "frs4"). To reset demo data, clear site data for the page.

Next step (optional): replace the localStorage calls (sess.get / sess.set / save()) in script.js with a backend API
(for example Node.js + Express + MongoDB or MySQL) so ratings are shared across devices.
